#  source("C:\\R Toolbox\\isnt.na.R")

# define isnt.na function
isnt.na <- function(x){(!is.na(x))}
